import os
import numpy as np
import matplotlib.pyplot as plt
import math as ma


# -archivo con las constantes opticas (cambiales el .dat a .lnk . Gmail
# no me las dejaba enviartelas con .lnk)
# - tamano minimo
# - tamano maximo
# - densidad (yo uso 4.0 para sio2 y 2.0 para amorphous carbon )
# - Numero de bins para calcular la opacidad promedio

# antes de ejecutarlo con "python opacities.py"
# debes hacer un make en la misma capeta
# 'version_0.38/opac/dust_continuum/bohrenhuffman/' para compilar el
# codigo que calcula las opacidades.



#-----------------------PARAMETERS

amin=0.1                        # microns
amax=10000                        # microns
# amorphous carbon density=2 
# silicates density=3-4 
density=3.2                     # g/cm3
N=75                            # bins
exponent=3.5                         # n(a) propto a^-exp


# lnk_file='ac_opct'
# lnk_file='sio2_ext'
lnk_file='Draine_Si'

path="./"

Type='Draine_Si'
# Type='ac_opct'

pathout='results/dustkappa_'+Type+'.inp'

#---------------------- MAIN 

Pa=(amax/amin)**(1.0/(N-1.0))

A=np.zeros(N)
A[0]=amin


for i in range(N):
    os.system('rm '+path+'param.inp')
    A[i]=amin*(Pa**(i))
    acm=A[i]*10.0**(-4.0)
    print "a = %1.2e [um]"  %A[i]
    file_inp=open(path+'param.inp','w')
    file_inp.write(lnk_file+'\n')
    e=round(ma.log10(acm))
    b=acm/(10.0**e)
    file_inp.write('%1.2fd%i \n' %(b,e))
    file_inp.write('%1.2f \n' %density) 
    file_inp.write('1')

    file_inp.close()

    os.system(path+'makeopac')
    
    os.system('mv '+path+'dustkappa_'+lnk_file+'.inp '+path+'results/dustkappa_'+Type+'_'+str(i+1)+'.inp ') 
   


#--------- READ OPACITIES AND COMPUTE MEAN OPACITY

# read number of wavelengths
opct=np.loadtxt(path+lnk_file+'.lnk')
Nw=len(opct[:,0])


Op=np.zeros((Nw,4)) # wl, kappa_abs, kappa_scat, g 
Op[:,0]=opct[:,0]

Ws_mass=np.zeros(N) # weigths by mass and abundances
Ws_number=np.zeros(N) # weights by abundances

for i in xrange(N):
    Ws_mass[i]=(A[i]**(-exponent))*(A[i]**(3.0))*A[i]  # w(a) propto n(a)*m(a)*da and da propto a
    Ws_number[i]=A[i]**(-exponent)*A[i]

W_mass=Ws_mass/np.sum(Ws_mass)
W_number=Ws_number/np.sum(Ws_number)

for i in xrange(N):
    file_inp=open(path+'results/dustkappa_'+Type+'_'+str(i+1)+'.inp','r')
    file_inp.readline()
    file_inp.readline()


    for j in xrange(Nw):
        line=file_inp.readline()
        dat=line.split()
        kabs=float(dat[1])
        kscat=float(dat[2])
        g=float(dat[3])

        Op[j,1]+=kabs*W_mass[i]
        Op[j,2]+=kscat*W_mass[i]
        Op[j,3]+=g*W_mass[i] 

    file_inp.close()
    os.system('rm '+path+'results/dustkappa_'+Type+'_'+str(i+1)+'.inp')

#---------- WRITE MEAN OPACITY

plt.plot(Op[:,0],Op[:,1])
plt.xscale('log')
plt.yscale('log')
plt.show()


final=open(path+pathout,'w')

final.write('3 \n')
final.write(str(Nw)+'\n')
for i in xrange(Nw):
    final.write('%f \t %f \t %f \t %f\n' %(Op[i,0],Op[i,1],Op[i,2],Op[i,3]))
final.close()

